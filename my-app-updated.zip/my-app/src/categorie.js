import React from 'react';
import {Row, Col, Tab, Tabs} from 'react-bootstrap';


export const Categorie = () => (
    <React.Fragment>
        <Row>
            <Col>
                <h2 className="app-title">Categories</h2>
            </Col>
        </Row>
        <Row>
            <Col>
            <Tabs defaultActiveKey="home" id="uncontrolled-tab-example">
                <Tab eventKey="home" title="Food">
                    Home
                </Tab>
                <Tab eventKey="profile" title="Profile">
                    Profile
                </Tab>
                <Tab eventKey="contact" title="Contact">
                    Contact
                </Tab>
            </Tabs>
            </Col>
        </Row>
    </React.Fragment>
)

