import React from 'react';
import { Home } from './home';
import { Categorie } from './categorie';
import { Cart } from './cart';
import { Payment } from './payment';
import { OppseError } from './oppseError';
import { Login } from './login';
import { BrowserRouter as Router, Route, Switch} from 'react-router-dom';
import {Layout} from './components/layout';
import { NavBar } from './components/navBar';
import { Notifications } from './components/notifications';



function App() {
  return (
    <React.Fragment>
    <NavBar/>
    <Layout>
      <Router>
        <Switch>
            <Route exact path="/" component={Home} />
            <Route  path="/categorie" component={Categorie} />
            <Route  path="/payment" component={Payment} />
            <Route  path="/cart" component={Cart} />
            <Route  path="/login" component={Login} />
            <Route  path="/notifications" component={Notifications} />
            <Route component={OppseError} />
        </Switch>
      </Router>
    </Layout>
    </React.Fragment>
  );
}

export default App;
