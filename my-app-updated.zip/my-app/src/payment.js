import React from 'react';
import { Row, Col } from 'react-bootstrap';
import './payment.css';
import { LeftNavbar } from './components/leftNav';
import InvoiceForm from './components/invoiceForm';
import AllInvoice from './components/invoiceData';

export const Payment = () => (
    <React.Fragment>
        <div className="payment-box">
        <Row className="justify-content-md-center align-center-center">
            <Col sm={4} md={2} >
                <LeftNavbar/>
            </Col>
            <Col sm={8} md={10} >
                <div className="add-from">
                    <InvoiceForm />
                </div>
                <div className="data-row">
                    <AllInvoice />
                </div>
            </Col>
        </Row>
        </div>
    </React.Fragment>
)