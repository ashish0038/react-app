import React, { Component } from 'react';
import { Row, Col } from 'react-bootstrap';
import { connect } from 'react-redux';
import InvoiceRow from './invoicerow';
//AllInvoice


class AllInvoice extends Component {



    render() {
        return (
            <div>
                <Row>
                    <Col sm={6}>
                        <h4 className="invoice-title">All Invoice</h4>
                    </Col>
                    <Col sm={6} className="text-right">
                        <h4 className="invoice-title-amount">Total: $
                            {
                                this.props.invoices.reduce((Totalamount, invoice) => Totalamount + parseInt(invoice.amount), 0)
                            }
                        </h4>
                    </Col>
                </Row>

                {console.log(this.props.invoices)}
                {this.props.invoices.map((invoice) => <InvoiceRow key={invoice.id} invoice={invoice} />)}
            </div>
        );
    }
}

const mapStateToProps = (state) => {
    return {
        invoices: state
    }
}
export default connect(mapStateToProps)(AllInvoice);