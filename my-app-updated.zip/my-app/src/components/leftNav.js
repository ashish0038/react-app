import React from 'react';
import './leftnav.css';
import swipecard from '../assests/swipecard.svg';
import scanstatement from '../assests/scanstatement.svg';
import manualsearch from '../assests/manualsearch.svg';

export const LeftNavbar = () => (
    <React.Fragment>
        <div className="nav-title">Lookup Menu</div>
        <div className="leftnav-box">

            <div className="nav-box">
                <div className="nav-inner">
                    <img src={swipecard} alt={swipecard} className="nav-img" />
                    <h4 className="nav-text">Swipe Card</h4>
                </div>
            </div>
            <div className="nav-box">
                <div className="nav-inner">
                    <img src={scanstatement} alt={scanstatement} className="nav-img" />
                    <h4 className="nav-text">Scan Statement</h4>
                </div>
            </div>
            <div className="nav-box">
                <div className="nav-inner">
                    <img src={manualsearch} alt={manualsearch} className="nav-img" />
                    <h4 className="nav-text">Manual Search</h4>
                </div>
            </div>
        </div>
    </React.Fragment>
)