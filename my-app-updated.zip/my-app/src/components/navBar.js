import React from 'react';
import { Nav, Navbar, NavDropdown} from 'react-bootstrap';
import logo from '../assests/lowes_logo.png';
import './navbar.css';

export const NavBar = (props) => (
    <Navbar bg="light" expand="lg" variant="light" className="box-shadow" fixed="top">
        <Navbar.Brand href="/" className="mr-auto d-lg-none d-xl-none"><img className="nav-logo" src={logo} alt={logo} /></Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
            <Navbar.Text className="mr-auto d-none d-lg-block my-logo-box">
                <a href="/"><i className="fa fa-angle-left header_arrow_left"></i> <span className="header-text"> Account Lookup | Take Payment </span></a>
            </Navbar.Text>
            {/* <Nav className="mr-auto">
                <Nav.Item> <Nav.Link href="/">Dashboard</Nav.Link> </Nav.Item>
                <NavDropdown title="Categories" id="collasible-nav-dropdown">
                    <NavDropdown.Item href="/Categorie">Break Fast</NavDropdown.Item>
                    <NavDropdown.Item href="/Categorie">Main Dishes</NavDropdown.Item>
                    <NavDropdown.Item href="/Categorie">Salad</NavDropdown.Item>
                    <NavDropdown.Item href="/Categorie">Drinks</NavDropdown.Item>
                </NavDropdown>
                <Nav.Item> <Nav.Link href="/addForm">Add Form</Nav.Link> </Nav.Item>
            </Nav> */}
            <Navbar.Brand href="/" className="mr-auto d-none d-lg-block"><img className="nav-logo" src={logo} alt={logo} /></Navbar.Brand>
            <Nav>
                <Navbar.Text className="mr-auto">
                    <a href="/"><i className="fa fa-clock-o header-icon"></i> <span className="header-text"> June 22, 2019 | 08:30 </span></a>
                </Navbar.Text>
                <Navbar.Text className="mr-auto">
                    <a href="/"><i className="fa fa-print header-icon"></i> <span className="header-text">  Printer </span> </a>
                </Navbar.Text>
                {/* <Nav.Item> <Nav.Link className="nav-icon" href="/notifications"><i className="fa fa-envelope-square"></i></Nav.Link> </Nav.Item>
                <Nav.Item> <Nav.Link className="nav-icon" href="/cart"><i className="fa fa-cart-arrow-down"></i></Nav.Link> </Nav.Item> */}
                <NavDropdown title="User Name" id="collasible-nav-dropdown" alignRight>
                    <NavDropdown.Item href="/Profile">Profile</NavDropdown.Item>
                    <NavDropdown.Item href="/Setting">Setting</NavDropdown.Item>
                    <NavDropdown.Item href="/Activity-logs">Activity Logs</NavDropdown.Item>
                    <NavDropdown.Divider />
                    <NavDropdown.Item href="/login">Logout</NavDropdown.Item>
                </NavDropdown>
            </Nav>
        </Navbar.Collapse>
    </Navbar>
)