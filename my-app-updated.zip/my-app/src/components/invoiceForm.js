import React, { Component } from 'react';
import {connect} from 'react-redux';
import { Row, Col,Form } from 'react-bootstrap';

class InvoiceForm extends Component {
  handleSubmit = (e) => {
    e.preventDefault();
    const number = this.getNumber.value;
    const amount =  this.getAmount.value;
    const data = {
      id: new Date(),
      number,
      amount
    }
    //console.log(data)
    this.props.dispatch({
      type:'ADD_POST',
      data});
    this.getNumber.value = '';
    this.getAmount.value = '';
  }
render() {
return (
<div>
  <form onSubmit={this.handleSubmit}>
   <Row>
    <Col md={5}>
        <Form.Group controlId="formBasicEmail">
            <Form.Label>Invoice #</Form.Label>
            <Form.Control required type="number" ref={(input)=>this.getNumber = input}  placeholder="Number #" />
        </Form.Group>
    </Col>
    <Col md={5}>
        <Form.Group controlId="formBasicEmail">
            <Form.Label>Amount </Form.Label>
            <Form.Control ref={(input)=>this.getAmount = input} required  type="number" placeholder="$00.00" />
        </Form.Group>
    </Col>
    <Col md={2}>
        <button className="Addpayment btn btn-primary" >Add</button>
    </Col>
</Row>  
  </form>
  
</div>
);
}
}
export default connect()(InvoiceForm);