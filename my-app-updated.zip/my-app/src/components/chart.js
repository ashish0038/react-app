import React from 'react';
import { BarChart, Bar, XAxis, Tooltip , CartesianGrid} from 'recharts';


const Products = [
    {name: 'Break Fast',  amt: 1400},
    {name: 'Main Dishes', amt: 400},
    {name: 'Salad', amt: 200},
    {name: 'Drinks', amt: 3000}
];

const Transitions = [
  {name: 'Todays', amt: 2400},
  {name: 'Weekly', amt: 12400},
  {name: 'Monthly', amt: 23000}
];


export const Chart1 = () => (
  <BarChart width={550} height={300} data={Products}>
    <XAxis dataKey="name" stroke="#434b52" />
    <Tooltip />
    <CartesianGrid stroke="#ccc" strokeDasharray="5 5" />
    <Bar type="monotone" dataKey="amt" fill="#9fadba" barSize={30} />
  </BarChart>
)

export const Chart2 = () => (
  <BarChart width={550} height={300} data={Transitions}>
    <XAxis dataKey="name" stroke="#434b52" />
    <Tooltip />
    <CartesianGrid stroke="#ccc" strokeDasharray="5 5" />
    <Bar type="monotone" dataKey="amt" fill="#9fadba" barSize={30} />
  </BarChart>
)