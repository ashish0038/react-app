import React, { Component } from 'react';
import { Row, Col } from 'react-bootstrap';
import {connect} from 'react-redux';
class InvoiceRow extends Component {
  render() {
  return (
    <div className="data-row">
        <Row>
            <Col sm={4} md={6} >
                <span className="row-data">Invoice No: <b>{this.props.invoice.number}</b> </span>
            </Col>
            <Col sm={4} md={4} className="text-right">
            <span className="row-data"> Amount: $<b>{this.props.invoice.amount}</b></span>
            </Col>
            <Col sm={4} md={2}  className="text-right">
                <span className="delete-btn" onClick={()=>this.props.dispatch({type:'DELETE_POST',id:this.props.invoice.id})}>
                    <i className="fa fa-trash delete-icon"></i>
                </span>

            </Col>
        </Row>
    </div> 
  );
 }
}
export default connect()(InvoiceRow);